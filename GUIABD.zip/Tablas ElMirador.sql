USE [master]
GO
IF EXISTS(SELECT * FROM sysdatabases WHERE name = 'ElMirador')
	DROP DATABASE ElMirador
ELSE
	CREATE DATABASE ElMirador

USE ElMirador
GO

CREATE TABLE Departamentos( 
Id int identity (1,1) primary key not null,
Nombre varchar (50) not null
)

CREATE TABLE Municipios(
Id int identity(1,1) primary key not null,
Nombre varchar(50) not null,
IdDepartamento int foreign key references Departamentos(Id)
)

CREATE TABLE Empleados(
Id int identity (1,1) primary key not null,
PrimerNombre varchar (20) not null,
SegundoNombre varchar (20),
PrimerApellido varchar (20) not null,
SegundoApellido varchar (20),
Cedula char(16) check(Cedula like '[0-9][0-9][0-9]-[0-3][0-9][0-1][0-9][0-2][0-9]-[0-9][0-9][0-9][0-9][A-Z]')not null,
Telefono char(8) check(Telefono like '[2|8|5|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') not null,
Correo nvarchar (50),
Direccion nvarchar (100),
Estado bit not null,
IdMunicipio int foreign key references Municipios(Id) not null
)

CREATE TABLE Usuarios(
Id int identity(1,1) primary key not null,
Nombre nvarchar(100) not null,
Contrase�a varbinary(8000) not null,
Rol nvarchar(40)not null,
Estado bit not null,
IdEmpleado int foreign key references Empleados(Id) not null
)

CREATE TABLE Clientes(
Id int identity (1,1) primary key not null,
Direccion nvarchar(100),
Telefono char(8) check(Telefono like '[2|8|5|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') not null,
Correo nvarchar(50),
Estado bit not null,
IdMunicipio int foreign key references Municipios(Id)not null
)

CREATE TABLE ClientesJuridicos(
Ruc char(12) primary key not null,
Nombre nvarchar(50)not null,
Tipo nvarchar(25) not null,
RLegal nvarchar(45) not null,
IdCliente int foreign key references Clientes(Id) not null,
)

CREATE TABLE ClientesNaturales(
Cedula char (16)check (Cedula like '[0-9][0-9][0-9]-[0-3][0-9][0-1][0-9][0-2][0-9]-[0-9][0-9][0-9][0-9][A-Z]') primary key not null,
PrimerNombre varchar (20) not null,
SegundoNombre varchar (20),
PrimerApellido varchar (20) not null,
SegundoApellido varchar (20),
Estado bit not null,
IdCliente int foreign key references Clientes(Id)not null
)

CREATE TABLE Proveedores(
Id int identity (1 ,1) primary key not null,
Nombre nvarchar(100) not null,
Direccion nvarchar(250) not null,
Telefono char (8) check(Telefono like '[2|8|5|7][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]') not null,
Estado bit not null
)

CREATE TABLE Compras(
Id int identity (1,1) primary key not null,
Fecha date not null,
IdEmpleado int foreign key references Empleados(Id) not null,
IdProveedor int foreign key references Proveedores(Id) not null,
Estado bit not null
)

CREATE TABLE Ingredientes (
Id int identity (1,1) primary key not null,
Nombre nvarchar(50) not null,
Imagen image,
FechaCaducidad date not null,
UnidadMedida varchar(100) not null,
Cantidad float not null,
Precio money not null,
Estado bit not null
)


CREATE TABLE Ventas(
Id int identity (1,1) primary key not null,
Fecha date not null,
IdEmpleado int foreign key references Empleados(Id) not null,
IdCliente int foreign key references Clientes(Id)Not null,
Estado bit not null
)


CREATE TABLE Platillos (
Id int identity (1,1) primary key not null,
Nombre nvarchar (30) not null,
Precio money not null,
Imagen image,
Estado bit not null
)

--Detalle Platillos
CREATE TABLE DetallePlatillo(
IdPlatillo int foreign key references Platillos(Id) not null,
IdIngrediente int foreign key references Ingredientes(Id) not null,
primary key (IdPlatillo, IdIngrediente) ,
Cantidad float not null,
Precio money not null,
Estado bit not null
)

--Detalle Compra
CREATE TABLE DetalleCompras(
IdCompra int foreign key references Compras(Id) not null,
IdIngredientes int foreign key references Ingredientes(Id)
primary key (IdCompra, IdIngredientes) not null,
Cantidad float not null,
Costo money not null,
Descuento float not null,
Estado bit not null
)


--Detalle Venta
CREATE TABLE DetalleVenta(
IdVenta int foreign key references Ventas(Id) not null,
IdPlatillo int foreign key references Platillos(Id)  not null,
primary key (IdVenta, IdPlatillo),
Cantidad float not null,
Precio money not null,
Descuento float not null,
Estado bit not null
)

CREATE TABLE DetallesCompras(
IdCompra int foreign key references Compras(Id) not null,
IdIngrediente int foreign key references Ingredientes(Id) not null,
primary key(IdCompra, IdIngrediente),
Cantidad float not null,
Costo money not null,
Descuento float not null,
Estado bit not null
)