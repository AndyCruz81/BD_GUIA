--CRUD Clientes
use ElMirador
CREATE PROCEDURE CLIENTES_CREATE
@Direccion nvarchar(max),
@Telefono char(8),
@Correo nvarchar(max),
@IdMunicipio int
AS
BEGIN

	--Validaciones
	IF (LEN(@Direccion) > 100)
	BEGIN
		RAISERROR('La longitud de caracteres de la direcci�n excede la permitida', 16, 1)
	END

	IF (@Telefono = '' OR @Telefono IS NULL)
	BEGIN
		RAISERROR('El tel�fono no puede estar vac�o', 16, 1)
	END

	IF (LEN(@Correo) > 50)
	BEGIN
		RAISERROR('La longitud de caracteres del correo excede la permitida', 16, 1)
	END

	IF (@IdMunicipio <= 0 OR @IdMunicipio IS NULL)
	BEGIN
		RAISERROR('El ID del municipio no existe', 16, 1)
	END

	--Operaciones
	INSERT INTO Clientes(Direccion, Telefono, Correo, Estado, IdMunicipio)
	VALUES(@Direccion, @Telefono, @Correo, 1, @IdMunicipio)

	--Resultado
	DECLARE @Id INT = SCOPE_IDENTITY()
	SELECT * FROM Clientes WHERE Id = @Id

END

CREATE PROCEDURE CLIENTES_READ
@Id int,
@Direccion nvarchar(max),
@Telefono char(8),
@Correo nvarchar(max),
@Estado bit,
@IdMunicipio int
AS
BEGIN
	SELECT
		*
	FROM
		Clientes
	WHERE (
	(@Id IS NULL OR Id = @Id) AND
	(@Direccion IS NULL OR Direccion LIKE '%' + @Direccion + '%') AND
	(@Telefono IS NULL OR Telefono LIKE '%' + @Telefono + '%') AND
	(@Correo IS NULL OR Correo LIKE '%' + @Correo + '%') AND
	(@Estado IS NULL OR Estado = @Estado) AND
	(@IdMunicipio IS NULL OR IdMunicipio = @IdMunicipio))
END

CREATE PROCEDURE CLIENTES_UPDATE
@Id int,
@Direccion nvarchar(max),
@Telefono char(8),
@Correo nvarchar(max),
@IdMunicipio int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del cliente no es v�lido', 16, 1)
	END

	IF (LEN(@Direccion) > 100)
	BEGIN
		RAISERROR('La longitud de caracteres de la direcci�n excede la permitida', 16, 1)
	END

	IF (@Telefono = '' OR @Telefono IS NULL)
	BEGIN
		RAISERROR('El tel�fono no puede estar vac�o', 16, 1)
	END

	IF (LEN(@Correo) > 50)
	BEGIN
		RAISERROR('La longitud de caracteres del correo excede la permitida', 16, 1)
	END

	IF (@IdMunicipio <= 0 OR @IdMunicipio IS NULL)
	BEGIN
		RAISERROR('El ID del municipio no existe', 16, 1)
	END

	--Operaciones
	UPDATE Clientes SET Direccion = @Direccion, Telefono = @Telefono, Correo = @Correo, IdMunicipio = @IdMunicipio
	WHERE Id = @Id

	--Resultado
	SELECT * FROM Clientes WHERE Id = @Id

END

CREATE PROCEDURE CLIENTES_DELETE
@Id int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del cliente no es v�lido', 16, 1)
	END

	--Operaciones
	UPDATE Clientes SET Estado = 0 WHERE Id = @Id

	--Resultado
	SELECT * FROM Clientes WHERE Id = @Id

END

--CRUD Clientes

--CRUD Clientes Juridicos
CREATE PROCEDURE CLIENTESJURIDICOS_CREATE
@Ruc char (12),
@Nombre nvarchar (max),
@Tipo nvarchar (max),
@RLegal nvarchar (max),
@IdCliente int
AS
BEGIN
	--Validaciones
	IF (@Ruc = '' or @Ruc is null )
	BEGIN
	    RAISERROR ('El espacio Ruc no puede quedar vac�o',16,1)
	END

	IF (LEN(@Ruc) > 12)
	BEGIN
		RAISERROR('La longitud de caracteres de el Ruc excede la permitida', 16, 1)
	END

	IF(@Nombre ='' or @Nombre is null)
	BEGIN
	    RAISERROR ('El campo Nombre no puede estar vac�o',16,1)
	END

	IF (LEN (@Nombre)>50)
	BEGIN
	    RAISERROR ('La longitud de caracteres de Nombre excede la permitida',16,1)
	END

	IF (@Tipo ='' OR @Tipo IS NULL)
	BEGIN
	    RAISERROR('El campo Tipo no puede estar vac�o',16,1)
	END

	IF (LEN (@Tipo)>25) 
	BEGIN
	    RAISERROR ('La longitud de caracteres de Tipo excede la permitida',16,1)
	END

	IF(@RLegal = ''OR @RLegal IS NULL)
	BEGIN
	    RAISERROR ('El campo RLegal no puede estar vac�o',16,1)
	END

	IF(LEN(@RLegal)>45)
	BEGIN
	    RAISERROR ('La longitud de caracteres de RLegal excede la permitida',16,1)
	END

	IF (@IdCliente <= 0 OR @IdCliente IS NULL)
	BEGIN
		RAISERROR('El ID del Cliente no existe', 16, 1)
	END

	--Operaciones
	INSERT INTO ClientesJuridicos (Ruc, Nombre, Tipo, RLegal, Estado, IdCliente)
	VALUES (@Ruc, @Nombre, @Tipo, @RLegal, 1, @IdCliente)

	--Resultado
	SELECT * FROM ClientesJuridicos WHERE Ruc = @Ruc

END

CREATE PROCEDURE CLIENTESJURIDICOS_READ
@Ruc char (12),
@Nombre nvarchar (max),
@Tipo nvarchar (max),
@RLegal nvarchar (max),
@IdCliente int,
@Estado bit
AS
BEGIN
	SELECT
		*
	FROM
		ClientesJuridicos
	WHERE (
	(@Ruc IS NULL OR Ruc = @Ruc) AND
	(@Nombre IS NULL OR Nombre LIKE '%' + @Nombre + '%') AND
	(@Tipo IS NULL OR Tipo LIKE '%' + @Tipo + '%') AND
	(@RLegal IS NULL OR RLegal LIKE '%' + @RLegal + '%') AND
	(@IdCliente IS NULL OR IdCliente = @IdCliente)AND
	(@Estado IS NULL OR Estado = @Estado) )
END

CREATE PROCEDURE CLIENTESJURIDICOS_UPDATE
@Ruc char (12),
@Nombre nvarchar (max),
@Tipo nvarchar (max),
@RLegal nvarchar (max),
@IdCliente int

AS
BEGIN
    --Validaciones
	IF (@Ruc = '' or @Ruc is null )
	BEGIN
	    RAISERROR ('El espacio Ruc no puede quedar vac�o',16,1)
	END

	IF (LEN(@Ruc) > 12)
	BEGIN
		RAISERROR('La longitud de caracteres de el Ruc excede la permitida', 16, 1)
	END

	IF(@Nombre ='' or @Nombre is null)
	BEGIN
	    RAISERROR ('El campo Nombre no puede estar vac�o',16,1)
	END

	IF (LEN (@Nombre)>50)
	BEGIN
	    RAISERROR ('La longitud de caracteres de Nombre excede la permitida',16,1)
	END

	IF (@Tipo ='' OR @Tipo IS NULL)
	BEGIN
	    RAISERROR('El campo Tipo no puede estar vac�o',16,1)
	END

	IF (LEN (@Tipo)>25) 
	BEGIN
	    RAISERROR ('La longitud de caracteres de Tipo excede la permitida',16,1)
	END

	IF(@RLegal = ''OR @RLegal IS NULL)
	BEGIN
	    RAISERROR ('El campo RLegal no puede estar vac�o',16,1)
	END

	IF(LEN(@RLegal)>45)
	BEGIN
	    RAISERROR ('La longitud de caracteres de RLegal excede la permitida',16,1)
	END

	IF (@IdCliente <= 0 OR @IdCliente IS NULL)
	BEGIN
		RAISERROR('El ID del Cliente no existe', 16, 1)
	END

	
	--Operaciones
	UPDATE ClientesJuridicos SET Nombre = @Nombre, Tipo = @Tipo, IdCliente = @IdCliente
	WHERE Ruc = @Ruc

	--Resultado
	SELECT * FROM ClientesJuridicos WHERE Ruc = @Ruc

END


CREATE PROCEDURE CLIENTESJURIDICOS_DELETE
@Ruc char(12)
AS
BEGIN

	--Validaciones
	IF (@Ruc = '' OR @Ruc IS NULL)
	BEGIN
		RAISERROR('El Ruc del cliente jur�dico no puede quedar vac�o', 16, 1)
	END

	IF (LEN(@Ruc) < 12 OR LEN(@Ruc) > 12)
	BEGIN
		RAISERROR('El Ruc del cliente Juridico no es v�lido. Aseg�rese de que contenga 12 caracteres exactos', 16, 1)
	END

	--Operaciones
	UPDATE ClientesJuridicos SET Estado = 0 WHERE Ruc = @Ruc

	--Resultado
	SELECT * FROM ClientesJuridicos WHERE Ruc = @Ruc

END

--CRUD Clientes Naturales
CREATE PROC CLIENTESNATURALES_CREATE
@Cedula CHAR (16),
@PrimerNombre VARCHAR(20),
@SegundoNombre VARCHAR(MAX),
@PrimerApellido VARCHAR (20),
@SegundoApellido VARCHAR(20),
@IdCliente int
AS
BEGIN
    --Validaciones
	IF(@Cedula= ''or @Cedula is null)
	BEGIN
	    RAISERROR('El campo C�dula no puede estar vac�o ',16,1)
	END

	IF(LEN(@Cedula)>16)
	BEGIN
	    RAISERROR('La longitud de caracteres de C�dula excede los permitidos',16,1)
	END

	IF(@PrimerNombre = '' OR @PrimerNombre IS NULL)
	BEGIN
	    RAISERROR('El campo Primer Nombre no puede estar vac�o',16,1)
	END

	IF(LEN(@PrimerNombre) > 20) 
	BEGIN
	    RAISERROR ('La longitud de caracteres de Primer Nombre excede los permitidos',16,1)
	END

	IF(LEN(@SegundoNombre) > 20)
	BEGIN
	    RAISERROR('La longitud de caracteres de Segundo Nombre excede los permitidos',16,1)
	END

	IF(@PrimerApellido='' OR @PrimerApellido IS NULL)
	BEGIN
	    RAISERROR('El campo Primer Apellido no puede estar vac�o',16,1)
	END

	IF(LEN(@PrimerApellido) > 20)
	BEGIN
	    RAISERROR('El campo Primer Apellido excede el limite de caracteres',16,1)
	END

	IF(LEN(@SegundoApellido) > 20)
	BEGIN
	    RAISERROR('El campo Segundo Apellido excede el limite de caracteres',16,1)
	END
	
	IF (@IdCliente <= 0 or @IdCliente is null)
	BEGIN
	    RAISERROR ('EL ID DEL CLIENTE NO EXISTE',16,1)
	END

	--Operaciones
	INSERT INTO ClientesNaturales(Cedula, PrimerNombre, SegundoNombre, PrimerApellido, SegundoApellido, Estado, IdCliente)
	VALUES(@Cedula, @PrimerNombre, @SegundoNombre, @PrimerApellido, @SegundoApellido, 1, @IdCliente)

	--Resultados
	SELECT * FROM ClientesNaturales WHERE Cedula = @Cedula
END

CREATE PROC CLIENTESNATURALES_READ
@Cedula CHAR (16),
@PrimerNombre VARCHAR(20),
@SegundoNombre VARCHAR(MAX),
@PrimerApellido VARCHAR (20),
@SegundoApellido VARCHAR(20),
@Estado BIT,
@IdCliente int
AS
BEGIN
     --Operaciones
	 SELECT 
	     *
	 FROM
	     ClientesNaturales
	 WHERE(
	(@Cedula IS NULL OR cedula = @Cedula) AND
	(@PrimerNombre IS NULL OR PrimerNombre LIKE '%' + @PrimerNombre + '%') AND
	(@SegundoNombre IS NULL OR SegundoNombre LIKE '%' + @SegundoNombre + '%') AND
	(@PrimerApellido IS NULL OR PrimerApellido LIKE '%' + @PrimerApellido + '%') AND
	(@SegundoApellido IS NULL OR SegundoApellido LIKE '%' + @SegundoApellido + '%') AND
	(@Estado IS NULL OR Estado = @Estado) AND
	(@IdCliente IS NULL OR IdCliente = @IdCliente))
END

CREATE PROC CLIENTESNATURALES_UPDATE
@Cedula CHAR (16),
@PrimerNombre VARCHAR(20),
@SegundoNombre VARCHAR(MAX),
@PrimerApellido VARCHAR (20),
@SegundoApellido VARCHAR(20),
@IdCliente int
AS
BEGIN
    --Validaciones
	IF(@Cedula= ''or @Cedula is null)
	BEGIN
	    RAISERROR('El campo C�dula no puede estar vac�o ',16,1)
	END

	IF(LEN(@Cedula)>16)
	BEGIN
	    RAISERROR('La longitud de caracteres de C�dula excede los permitidos',16,1)
	END

	IF(@PrimerNombre = '' OR @PrimerNombre IS NULL)
	BEGIN
	    RAISERROR('El campo Primer Nombre no puede estar vac�o',16,1)
	END

	IF(LEN(@PrimerNombre) > 20) 
	BEGIN
	    RAISERROR ('La longitud de caracteres de Primer Nombre excede los permitidos',16,1)
	END

	IF(LEN(@SegundoNombre) > 20)
	BEGIN
	    RAISERROR('La longitud de caracteres de Segundo Nombre excede los permitidos',16,1)
	END

	IF(@PrimerApellido='' OR @PrimerApellido IS NULL)
	BEGIN
	    RAISERROR('El campo Primer Apellido no puede estar vac�o',16,1)
	END

	IF(LEN(@PrimerApellido) > 20)
	BEGIN
	    RAISERROR('El campo Primer Apellido excede el limite de caracteres',16,1)
	END

	IF(LEN(@SegundoApellido) > 20)
	BEGIN
	    RAISERROR('El campo Segundo Apellido excede el limite de caracteres',16,1)
	END
	
	IF (@IdCliente <= 0 or @IdCliente is null)
	BEGIN
	    RAISERROR ('EL ID DEL CLIENTE NO EXISTE',16,1)
	END

	--Operaciones
	UPDATE ClientesNaturales SET 
	PrimerNombre = @PrimerNombre,
	SegundoNombre = @SegundoNombre,
	PrimerApellido = @PrimerApellido,
	SegundoApellido = @SegundoApellido,
	IdCliente = @IdCliente
	WHERE Cedula = @Cedula

	--Resultado
	SELECT * FROM ClientesNaturales WHERE Cedula = @Cedula
END


CREATE PROC CLIENTESNATURALES_DELETE
@Cedula CHAR(16)
AS
BEGIN

    --VALIDACIONES
	IF (@Cedula = '' OR @Cedula IS NULL)
	BEGIN
		RAISERROR('La c�dula del cliente no puede estar vac�a', 16, 1)
	END

	IF (LEN(@Cedula) < 16 OR LEN(@Cedula) > 16)
	BEGIN
		RAISERROR('La Cedula del cliente no es v�lida. Aseg�rese de que contenga 16 caracteres', 16, 1)
	END

	--Operaciones
	UPDATE ClientesNaturales SET Estado = 0 WHERE Cedula = @Cedula

	--Resultado
	SELECT * FROM ClientesNaturales WHERE Cedula = @Cedula
END

--CRUD Compras

CREATE PROCEDURE COMPRAS_CREATE
@Fecha datetime,
@IdEmpleado int,
@IdProveedor int
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@Fecha IS NULL)
			BEGIN
				RAISERROR('La fecha de la compra no puede quedar vac�a.', 16, 1)
			END

			IF (@IdEmpleado <= 0 OR @IdEmpleado IS NULL)
			BEGIN
				RAISERROR('El ID del empleado no es v�lido.', 16, 1)
			END

			IF (@IdProveedor <= 0 OR @IdProveedor IS NULL)
			BEGIN
				RAISERROR('El ID del proveedor no es v�lido.', 16, 1)
			END

			--Operaciones
			INSERT INTO Compras (Fecha, IdEmpleado, IdProveedor, Estado)
			VALUES (@Fecha, @IdEmpleado, @IdProveedor, 1)

			--Resultado
			DECLARE @Id INT = SCOPE_IDENTITY()
			SELECT * FROM Compras WHERE Id = @Id
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE COMPRAS_READ
@Id int,
@Fecha datetime,
@IdEmpleado int,
@IdProveedor int,
@Estado bit
AS
BEGIN
	--Operaciones
	SELECT
		*
	FROM
		Compras
	WHERE (
	(@Id IS NULL OR Id = @Id) AND
	(@Fecha IS NULL OR Fecha = @Fecha) AND
	(@IdEmpleado IS NULL OR IdEmpleado = @IdEmpleado) AND
	(@IdProveedor IS NULL OR IdProveedor = @IdProveedor) AND
	(@Estado IS NULL OR Estado = @Estado))
END

CREATE PROCEDURE COMPRAS_UPDATE
@Id int,
@Fecha datetime,
@IdEmpleado int,
@IdProveedor int,
@Estado bit
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@Id <= 0 OR @Id IS NULL)
			BEGIN
				RAISERROR('El ID de la compra no es v�lido.', 16, 1)
			END

			IF (@Fecha IS NULL)
			BEGIN
				RAISERROR('La fecha de la compra no puede quedar vac�a.', 16, 1)
			END

			IF (@IdEmpleado <= 0 OR @IdEmpleado IS NULL)
			BEGIN
				RAISERROR('El ID del empleado no es v�lido.', 16, 1)
			END

			IF (@IdProveedor <= 0 OR @IdProveedor IS NULL)
			BEGIN
				RAISERROR('El ID del proveedor no es v�lido.', 16, 1)
			END

			--Operaciones
			UPDATE Compras SET Fecha = @Fecha, IdEmpleado = @IdEmpleado, IdProveedor = @IdProveedor
			WHERE Id = @Id

			--Resultado
			SELECT * FROM Compras WHERE Id = @Id
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE COMPRAS_DELETE
@Id int
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@Id <= 0 OR @Id IS NULL)
			BEGIN
				RAISERROR('El ID de la compra no es v�lido.', 16, 1)
			END

			--Operaciones
			UPDATE Compras SET Estado = 0 WHERE Id = @Id

			--Resultado
			SELECT * FROM Compras WHERE Id = @Id
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

--CRUD Compras

--CRUD Departamentos

CREATE PROC DEPARTAMENTOS_READ
@Id int,
@Nombre varchar(max)
AS
BEGIN
   
	SELECT
		*
	FROM
		Departamentos 
	WHERE (
	(@Id IS NULL OR Id = @Id) AND
	(@Nombre IS NULL OR Nombre LIKE '%' + @Nombre + '%'))
END

--CRUD Departamentos

--CRUD Detalle de Compras

CREATE PROCEDURE DETALLE_COMPRAS_CREATE
@IdCompra int,
@IdMateriaPrima int,
@Cantidad int,
@Costo money,
@Descuento float
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdCompra <= 0 OR @IdCompra IS NULL)
			BEGIN
				RAISERROR('El ID de la compra no es v�lido.', 16, 1)
			END

			IF (@IdMateriaPrima <= 0 OR @IdMateriaPrima IS NULL)
			BEGIN
				RAISERROR('El ID de la materia prima no es v�lido.', 16, 1)
			END

			IF (@Cantidad IS NULL OR @Cantidad <= 0)
			BEGIN
				RAISERROR('La cantidad a comprar no puede quedar vac�a o ser un n�mero negativo.', 16, 1)
			END

			IF (@Costo IS NULL OR @Costo <= 0)
			BEGIN
				RAISERROR('El costo del bien adquirido no puede quedar vac�o o ser un n�mero negativo.', 16, 1)
			END

			IF (@Descuento IS NULL OR @Descuento < 0)
			BEGIN
				RAISERROR('El descuento no puede ser nulo. Si no existe, digite 0 (cero).', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra)
			BEGIN
				RAISERROR('La compra a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima)
			BEGIN
				RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			--Operaciones
			INSERT INTO DetalleCompras (IdCompra, IdMateriaPrima, Cantidad, Costo, Descuento, Estado)
			VALUES (@IdCompra, @IdMateriaPrima, @Cantidad, @Costo, @Descuento, 1)

			--Resultado
			SELECT * FROM DetalleCompras WHERE (IdCompra = @IdCompra AND IdMateriaPrima = @IdMateriaPrima)
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE DETALLE_COMPRAS_READ
@IdCompra int,
@IdMateriaPrima int,
@Cantidad int,
@Costo money,
@Descuento float,
@Estado bit
AS
BEGIN
	--Operaciones
	SELECT
		*
	FROM
		DetalleCompras
	WHERE (
	(@IdCompra IS NULL OR IdCompra = @IdCompra) AND
	(@IdMateriaPrima IS NULL OR IdMateriaPrima = @IdMateriaPrima) AND
	(@Cantidad IS NULL OR Cantidad = @Cantidad) AND
	(@Costo IS NULL OR Costo = @Costo) AND
	(@Descuento IS NULL OR Descuento = @Descuento) AND
	(@Estado IS NULL OR Estado = @Estado))
END

CREATE PROCEDURE DETALLE_COMPRAS_UPDATE
@IdCompra int,
@IdMateriaPrima int,
@Cantidad int,
@Costo money,
@Descuento float
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdCompra <= 0 OR @IdCompra IS NULL)
			BEGIN
				RAISERROR('El ID de la compra no es v�lido.', 16, 1)
			END

			IF (@IdMateriaPrima <= 0 OR @IdMateriaPrima IS NULL)
			BEGIN
				RAISERROR('El ID de la materia prima no es v�lido.', 16, 1)
			END

			IF (@Cantidad IS NULL OR @Cantidad <= 0)
			BEGIN
				RAISERROR('La cantidad a comprar no puede quedar vac�a o ser un n�mero negativo.', 16, 1)
			END

			IF (@Costo IS NULL OR @Costo <= 0)
			BEGIN
				RAISERROR('El costo del bien adquirido no puede quedar vac�o o ser un n�mero negativo.', 16, 1)
			END

			IF (@Descuento IS NULL OR @Descuento < 0)
			BEGIN
				RAISERROR('El descuento no puede ser nulo. Si no existe, digite 0 (cero).', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra)
			BEGIN
				RAISERROR('La compra a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima)
			BEGIN
				RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			--Operaciones
			UPDATE DetalleCompras SET Cantidad = @Cantidad, Costo = @Costo, Descuento = @Descuento
			WHERE (IdCompra = @IdCompra AND IdMateriaPrima = @IdMateriaPrima)

			--Resultado
			SELECT * FROM DetalleCompras WHERE (IdCompra = @IdCompra AND IdMateriaPrima = @IdMateriaPrima)
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE DETALLE_COMPRAS_DELETE
@IdCompra int,
@IdMateriaPrima int
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdCompra <= 0 OR @IdCompra IS NULL)
			BEGIN
				RAISERROR('El ID de la compra no es v�lido.', 16, 1)
			END

			IF (@IdMateriaPrima <= 0 OR @IdMateriaPrima IS NULL)
			BEGIN
				RAISERROR('El ID de la materia prima no es v�lido.', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra)
			BEGIN
				RAISERROR('La compra a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Compras WHERE Id = @IdCompra AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima)
			BEGIN
				RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM MateriaPrima WHERE Id = @IdMateriaPrima AND Estado = 0)
			BEGIN
				RAISERROR('La compra a la que se hace referencia est� eliminada.', 16, 1)
			END

			--Operaciones
			UPDATE DetalleCompras SET Estado = 0
			WHERE (IdCompra = @IdCompra AND IdMateriaPrima = @IdMateriaPrima)

			--Resultado
			SELECT * FROM DetalleCompras WHERE (IdCompra = @IdCompra AND IdMateriaPrima = @IdMateriaPrima)

			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

--CRUD Detalle de compras

--CRUD Detalle de platillos

CREATE PROCEDURE DETALLE_PLATILLO_CREATE
@IdPlatillo int,
@IdMateriaPrima int,
@Cantidad float,
@Precio money
AS
BEGIN
	--Validaciones
	IF (@IdPlatillo IS NULL OR @IdPlatillo <= 0)
	BEGIN
		RAISERROR('El ID del platillo al que se hace referencia no es v�lido', 16, 1)
	END

	IF (@IdMateriaPrima IS NULL OR @IdMateriaPrima <= 0)
	BEGIN
		RAISERROR('El ID de la materia prima a la que se hace referencia no es v�lido.', 16, 1)
	END

	IF (@Cantidad IS NULL OR @Cantidad <= 0)
	BEGIN
		RAISERROR('La cantidad digitada no es permitida.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia est� eliminada.', 16, 1)
	END

	DECLARE @StockMateriaPrima FLOAT = (SELECT Cantidad FROM MateriaPrima WHERE Id = @IdMateriaPrima)

	IF (@Cantidad > @StockMateriaPrima)
	BEGIN
		RAISERROR('No existe la cantidad suficiente de materia prima para elaborar el platillo.', 16, 1)
	END

	IF (@Precio IS NULL OR @Precio <= 0)
	BEGIN
		RAISERROR('El precio de la materia prima no es v�lido.', 16, 1)
	END

	--Operaciones
	INSERT INTO DetallePlatillo (IdPlatillo, IdMateriaPrima, Cantidad, Precio, Estado)
	VALUES (@IdPlatillo, @IdMateriaPrima, @Cantidad, @Precio, 1)

	--Resultado
	SELECT * FROM DetallePlatillo WHERE (IdPlatillo = @IdPlatillo AND IdMateriaPrima = @IdMateriaPrima)
END

CREATE PROCEDURE DETALLE_PLATILLO_READ
@IdPlatillo int,
@IdMateriaPrima int,
@Cantidad float,
@Precio money,
@Estado bit
AS
BEGIN
	--Operaciones
	SELECT
		*
	FROM
		DetallePlatillo
	WHERE (
	(@IdPlatillo IS NULL OR IdPlatillo = @IdPlatillo) AND
	(@IdMateriaPrima IS NULL OR IdMateriaPrima = @IdMateriaPrima) AND
	(@Cantidad IS NULL OR Cantidad = @Cantidad) AND
	(@Precio IS NULL OR Precio = @Precio) AND
	(@Estado IS NULL OR Estado = @Estado))
END

CREATE PROCEDURE DETALLE_PLATILLO_UPDATE
@IdPlatillo int,
@IdMateriaPrima int,
@Cantidad float,
@Precio money
AS
BEGIN
	--Validaciones
	IF (@IdPlatillo IS NULL OR @IdPlatillo <= 0)
	BEGIN
		RAISERROR('El ID del platillo al que se hace referencia no es v�lido', 16, 1)
	END

	IF (@IdMateriaPrima IS NULL OR @IdMateriaPrima <= 0)
	BEGIN
		RAISERROR('El ID de la materia prima a la que se hace referencia no es v�lido.', 16, 1)
	END

	IF (@Cantidad IS NULL OR @Cantidad <= 0)
	BEGIN
		RAISERROR('La cantidad digitada no es permitida.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia est� eliminada.', 16, 1)
	END

	DECLARE @StockMateriaPrima FLOAT = (SELECT Cantidad FROM MateriaPrima WHERE Id = @IdMateriaPrima)

	IF (@Cantidad > @StockMateriaPrima)
	BEGIN
		RAISERROR('No existe la cantidad suficiente de materia prima para elaborar el platillo.', 16, 1)
	END

	IF (@Precio IS NULL OR @Precio <= 0)
	BEGIN
		RAISERROR('El precio de la materia prima no es v�lido.', 16, 1)
	END

	--Operaciones
	UPDATE DetallePlatillo SET Cantidad = @Cantidad, Precio = @Precio
	WHERE (IdPlatillo = @IdPlatillo AND IdMateriaPrima = @IdMateriaPrima)

	--Resultado
	SELECT * FROM DetallePlatillo WHERE (IdPlatillo = @IdPlatillo AND IdMateriaPrima = @IdMateriaPrima)
END

CREATE PROCEDURE DETALLE_PLATILLO_DELETE
@IdPlatillo int,
@IdMateriaPrima int
AS
BEGIN
	--Validaciones
	IF (@IdPlatillo IS NULL OR @IdPlatillo <= 0)
	BEGIN
		RAISERROR('El ID del platillo al que se hace referencia no es v�lido', 16, 1)
	END

	IF (@IdMateriaPrima IS NULL OR @IdMateriaPrima <= 0)
	BEGIN
		RAISERROR('El ID de la materia prima a la que se hace referencia no es v�lido.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
	END

	IF NOT EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia no existe.', 16, 1)
	END

	IF EXISTS(SELECT * FROM MateriaPrima WHERE Id = @IdPlatillo AND Estado = 0)
	BEGIN
		RAISERROR('La materia prima a la que se hace referencia est� eliminada.', 16, 1)
	END

	--Operaciones
	UPDATE DetallePlatillo SET Estado = 0 WHERE (IdPlatillo = @IdPlatillo AND IdMateriaPrima = @IdMateriaPrima)

	--Resultado
	SELECT * FROM DetallePlatillo WHERE (IdPlatillo = @IdPlatillo AND IdMateriaPrima = @IdMateriaPrima)
END

--CRUD Detalle de platillos

--CRUD Detalle de Ventas

CREATE PROCEDURE DETALLE_VENTAS_CREATE
@IdVenta int,
@IdPlatillo int,
@Cantidad int,
@Precio money,
@Descuento float
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdVenta <= 0 OR @IdVenta IS NULL)
			BEGIN
				RAISERROR('El ID de la venta no es v�lido.', 16, 1)
			END

			IF (@IdPlatillo <= 0 OR @IdPlatillo IS NULL)
			BEGIN
				RAISERROR('El ID del platillo no es v�lido.', 16, 1)
			END

			IF (@Cantidad IS NULL OR @Cantidad <= 0)
			BEGIN
				RAISERROR('La cantidad a comprar no puede quedar vac�a o ser un n�mero negativo.', 16, 1)
			END

			IF (@Precio IS NULL OR @Precio <= 0)
			BEGIN
				RAISERROR('El precio de venta no puede quedar vac�o o ser un n�mero negativo.', 16, 1)
			END

			IF (@Descuento IS NULL OR @Descuento < 0)
			BEGIN
				RAISERROR('El descuento no puede ser nulo. Si no existe, digite 0 (cero).', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta)
			BEGIN
				RAISERROR('La venta a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta AND Estado = 0)
			BEGIN
				RAISERROR('La venta a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo)
			BEGIN
				RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
			BEGIN
				RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
			END

			DECLARE @StockPlatillo INT = (SELECT Cantidad FROM Platillos WHERE Id = @IdPlatillo)

			IF (@Cantidad > @StockPlatillo)
			BEGIN
				RAISERROR('No existe suficiente cantidad de platillos para realizar la venta.', 16, 1)
			END

			--Operaciones
			INSERT INTO DetalleVenta(IdVenta, IdPlatillo, Cantidad, Precio, Descuento, Estado)
			VALUES (@IdVenta, @IdPlatillo, @Cantidad, @Precio, @Descuento, 1)

			--Resultado
			SELECT * FROM DetalleVenta WHERE (IdVenta = @IdVenta AND IdPlatillo = @IdPlatillo)
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE DETALLE_VENTAS_READ
@IdVenta int,
@IdPlatillo int,
@Cantidad int,
@Precio money,
@Descuento float,
@Estado bit
AS
BEGIN
	--Operaciones
	SELECT
		*
	FROM
		DetalleVenta
	WHERE (
	(@IdVenta IS NULL OR IdVenta = @IdVenta) AND
	(@IdPlatillo IS NULL OR IdPlatillo = @IdPlatillo) AND
	(@Cantidad IS NULL OR Cantidad = @Cantidad) AND
	(@Precio IS NULL OR Precio = @Precio) AND
	(@Descuento IS NULL OR Descuento = @Descuento) AND
	(@Estado IS NULL OR Estado = @Estado))
END

CREATE PROCEDURE DETALLE_VENTAS_UPDATE
@IdVenta int,
@IdPlatillo int,
@Cantidad int,
@Precio money,
@Descuento float
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdVenta <= 0 OR @IdVenta IS NULL)
			BEGIN
				RAISERROR('El ID de la venta no es v�lido.', 16, 1)
			END

			IF (@IdPlatillo <= 0 OR @IdPlatillo IS NULL)
			BEGIN
				RAISERROR('El ID del platillo no es v�lido.', 16, 1)
			END

			IF (@Cantidad IS NULL OR @Cantidad <= 0)
			BEGIN
				RAISERROR('La cantidad a comprar no puede quedar vac�a o ser un n�mero negativo.', 16, 1)
			END

			IF (@Precio IS NULL OR @Precio <= 0)
			BEGIN
				RAISERROR('El precio de venta no puede quedar vac�o o ser un n�mero negativo.', 16, 1)
			END

			IF (@Descuento IS NULL OR @Descuento < 0)
			BEGIN
				RAISERROR('El descuento no puede ser nulo. Si no existe, digite 0 (cero).', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta)
			BEGIN
				RAISERROR('La venta a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta AND Estado = 0)
			BEGIN
				RAISERROR('La venta a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo)
			BEGIN
				RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
			BEGIN
				RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
			END

			DECLARE @StockPlatillo INT = (SELECT Cantidad FROM Platillos WHERE Id = @IdPlatillo)

			IF (@Cantidad > @StockPlatillo)
			BEGIN
				RAISERROR('No existe suficiente cantidad de platillos para realizar la venta.', 16, 1)
			END

			--Operaciones
			UPDATE DetalleVenta SET Cantidad = @Cantidad, Precio = @Precio, Descuento = @Descuento
			WHERE (IdVenta = @IdVenta AND IdPlatillo = @IdPlatillo)

			--Resultado
			SELECT * FROM DetalleVenta WHERE (IdVenta = @IdVenta AND IdPlatillo = @IdPlatillo)
			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

CREATE PROCEDURE DETALLE_VENTAS_DELETE
@IdVenta int,
@IdPlatillo int
AS
BEGIN
	BEGIN TRY
		BEGIN TRANSACTION
			--Validaciones
			IF (@IdVenta <= 0 OR @IdVenta IS NULL)
			BEGIN
				RAISERROR('El ID de la venta no es v�lido.', 16, 1)
			END

			IF (@IdPlatillo <= 0 OR @IdPlatillo IS NULL)
			BEGIN
				RAISERROR('El ID del platillo no es v�lido.', 16, 1)
			END

			IF NOT EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta)
			BEGIN
				RAISERROR('La venta a la que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS(SELECT * FROM Ventas WHERE Id = @IdVenta AND Estado = 0)
			BEGIN
				RAISERROR('La venta a la que se hace referencia est� eliminada.', 16, 1)
			END

			IF NOT EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo)
			BEGIN
				RAISERROR('El platillo al que se hace referencia no existe.', 16, 1)
			END

			IF EXISTS (SELECT * FROM Platillos WHERE Id = @IdPlatillo AND Estado = 0)
			BEGIN
				RAISERROR('El platillo al que se hace referencia est� eliminado.', 16, 1)
			END

			--Operaciones
			UPDATE DetalleVenta SET Estado = 0
			WHERE (IdVenta = @IdVenta AND IdPlatillo = @IdPlatillo)

			--Resultado
			SELECT * FROM DetalleVenta WHERE (IdVenta = @IdVenta AND IdPlatillo = @IdPlatillo)

			COMMIT TRANSACTION
	END TRY

	BEGIN CATCH
		ROLLBACK TRANSACTION
	END CATCH
END

--CRUD Detalle de Ventas

--CRUD Empleados



--CRUD Empleados

--CRUD Materia prima

CREATE PROCEDURE MATERIAPRIMA_CREATE
@Nombre nvarchar(max),
@Imagen image,
@FechaCaducidad date,
@UnidadMedida varchar(max),
@Cantidad float,
@Precio money
AS
BEGIN
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN (@Nombre)>50)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el limite  permitido',16,1)
	END

	IF(@FechaCaducidad IS NULL)
	BEGIN
		RAISERROR ('La fecha de caducidad no puede estar vacia',16,1)
	END

	IF(@UnidadMedida='' OR @UnidadMedida IS NULL)
	BEGIN
		RAISERROR ('La unidad de medida, no puede estar vacia ',16,1)
	END

	IF(LEN (@UnidadMedida)>100)
	BEGIN
		RAISERROR ('La longitud de caracteres de la unidad de medida supera el limite  permitido',16,1)
	END

	IF(@Cantidad IS NULL)
	BEGIN
		RAISERROR ('La cantidad no puede estar vacia',16,1)
	END

	IF (@Cantidad <= 0)
	BEGIN
		RAISERROR ('La cantidad no puede ser menor o igual a 0',16,1)
	END

	IF( @Precio IS NULL)
	BEGIN
		RAISERROR ('El precio no puede estar vacio',16,1)
	END

	IF (@Precio<=0)
	BEGIN
		RAISERROR ('El precio no puede ser menor o igual a 0',16,1)
	END
	
	--Operaciones 
	INSERT INTO MateriaPrima (Nombre, Imagen, FechaCaducidad, UnidadMedida, Cantidad, Precio, Estado)
	VALUES (@Nombre, @Imagen, @FechaCaducidad, @UnidadMedida, @Cantidad, @Precio, 1)

	--Resultado 
	DECLARE @Id INT = SCOPE_IDENTITY ()
	SELECT * FROM  MateriaPrima WHERE Id = @Id
END

CREATE PROCEDURE MATERIAPRIMA_READ
@Id int ,
@Nombre nvarchar(max),
@Imagen image,
@FechaCaducidad date,
@UnidadMedida varchar(max),
@Cantidad float,
@Precio money,
@Estado bit
AS 
BEGIN
	SELECT * FROM
	MateriaPrima 
	WHERE (
	(@Id IS NULL OR Id = @Id) AND
	(@Nombre IS NULL OR Nombre LIKE '%' + @Nombre + '%') AND
	(@FechaCaducidad IS NULL OR FechaCaducidad = @FechaCaducidad) AND
	(@UnidadMedida IS NULL OR UnidadMedida LIKE '%' + @UnidadMedida + '%') AND
	(@Cantidad IS NULL OR Cantidad = @Cantidad) AND
	(@Precio IS NULL OR Precio = @Precio) AND
	(@Estado IS NULL OR Estado = @Estado))
END


CREATE PROCEDURE MATERIAPRIMA_UPDATE
@Id int,
@Nombre nvarchar(max),
@Imagen image,
@FechaCaducidad date,
@UnidadMedida varchar(max),
@Cantidad float,
@Precio money
AS 
BEGIN
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN (@Nombre)>50)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el limite  permitido',16,1)
	END

	IF(@FechaCaducidad IS NULL)
	BEGIN
		RAISERROR ('La fecha de caducidad no puede estar vacia',16,1)
	END

	IF(@UnidadMedida='' OR @UnidadMedida IS NULL)
	BEGIN
		RAISERROR ('La unidad de medida, no puede estar vacia ',16,1)
	END

	IF(LEN (@UnidadMedida)>100)
	BEGIN
		RAISERROR ('La longitud de caracteres de la unidad de medida supera el limite  permitido',16,1)
	END

	IF(@Cantidad IS NULL)
	BEGIN
		RAISERROR ('La cantidad no puede estar vacia',16,1)
	END

	IF (@Cantidad <= 0)
	BEGIN
		RAISERROR ('La cantidad no puede ser menor o igual a 0',16,1)
	END

	IF( @Precio IS NULL)
	BEGIN
		RAISERROR ('El precio no puede estar vacio',16,1)
	END

	IF (@Precio<=0)
	BEGIN
		RAISERROR ('El precio no puede ser menor o igual a 0',16,1)
	END

	--OPERACIONES
	UPDATE MateriaPrima SET 
	Nombre = @Nombre, 
	Imagen = @Imagen,
	FechaCaducidad = @FechaCaducidad, 
	UnidadMedida = @UnidadMedida,
	Cantidad = @Cantidad,
	Precio = @Precio
	WHERE Id = @Id

	--Resultado
	SELECT * FROM MateriaPrima WHERE Id = @Id
END

CREATE PROCEDURE MATERIAPRIMA_DELETE
@Id int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID de la materia prima no es v�lido', 16, 1)
	END

	--Operaciones
	UPDATE MateriaPrima SET Estado = 0 WHERE Id = @Id

	--Resultado
	SELECT * FROM MateriaPrima WHERE Id = @Id

END

--CRUD Materia prima

--CRUD Municipios

CREATE PROCEDURE MUNICIPIOS_READ
@Id int,
@Nombre varchar(max),
@IdDepartamento int
AS
BEGIN
	--Operaciones
	SELECT
		*
	FROM
		Municipios
	WHERE (
		(@Id IS NULL OR Id = @Id) AND
		(@Nombre IS NULL OR Nombre LIKE '%' + @Nombre + '%') AND
		(@IdDepartamento IS NULL OR IdDepartamento = @IdDepartamento))
END

--CRUD Municipios

--CRUD Platillos

CREATE PROCEDURE PLATILLOS_CREATE
@Nombre nvarchar(max),
@Precio money,
@Cantidad int,
@Imagen image
AS
BEGIN
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN (@Nombre)>30)
	BEGIN
		RAISERROR ('La longitud de caracteres supera el limite permitido',16,1)
	END

	IF( @Precio IS NULL)
	BEGIN
		RAISERROR ('El precio no puede estar vacio',16,1)
	END

	IF (@Precio<=0)
	BEGIN
		RAISERROR ('El precio no puede ser menor o igual a 0',16,1)
	END

	IF (@Cantidad <= 0 OR @Cantidad IS NULL)
	BEGIN
		RAISERROR('La cantidad del platillo no es v�lida.', 16, 1)
	END

	--Opreaciones
	INSERT INTO Platillos (Nombre, Precio, Cantidad, Imagen, Estado)
	VALUES (@Nombre,@Precio, @Cantidad, @Imagen,1)

	--Resultado
	DECLARE @Id INT = SCOPE_IDENTITY ()
	SELECT * FROM Platillos WHERE Id = @Id

END

CREATE PROCEDURE PLATILLOS_READ
@Id int ,
@Nombre nvarchar(max),
@Precio money,
@Cantidad int,
@Imagen image,
@Estado bit
AS 
BEGIN
	SELECT * FROM
	Platillos 
	WHERE (
	(@Id IS NULL OR Id = @Id) AND
	(@Nombre IS NULL OR Nombre LIKE '%' + @Nombre + '%') AND
	(@Precio IS NULL OR Precio = @Precio) AND
	(@Cantidad IS NULL OR Cantidad = @Cantidad) AND
	(@Estado IS NULL OR Estado = @Estado))
END

CREATE PROCEDURE PLATILLOS_UPDATE
@Id int,
@Nombre nvarchar(max),
@Precio money,
@Cantidad int,
@Imagen image

AS 
BEGIN
	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del platillo no es v�lido.', 16, 1)
	END

	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN (@Nombre)>30)
	BEGIN
		RAISERROR ('La longitud de caracteres supera el limite permitido',16,1)
	END

	IF( @Precio IS NULL)
	BEGIN
		RAISERROR ('El precio no puede estar vacio',16,1)
	END

	IF (@Precio<=0)
	BEGIN
		RAISERROR ('El precio no puede ser menor o igual a 0',16,1)
	END

	IF (@Cantidad <= 0 OR @Cantidad IS NULL)
	BEGIN
		RAISERROR('La cantidad del platillo no es v�lida.', 16, 1)
	END

	--OPERACIONES 
	UPDATE Platillos SET Nombre=@Nombre, Precio=@Precio, Cantidad = @Cantidad, Imagen=@Imagen
	WHERE Id=@Id

	--RESULTADO 
	SELECT * FROM Platillos WHERE Id=@Id
END

CREATE PROCEDURE PLATILLOS_DELETE
@Id int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del platillo no es v�lido', 16, 1)
	END

	--Operaciones
	UPDATE Platillos SET Estado = 0 WHERE Id = @Id

	--Resultado
	SELECT * FROM Platillos WHERE Id = @Id
END

--CRUD Platillos

--CRUD Proveedores

CREATE PROCEDURE PROVEEDORES_CREATE
@Nombre nvarchar(max),
@Direccion nvarchar(max),
@Telefono char(8)
AS
BEGIN
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN(@Nombre)>100)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el l�mite establecido',16,1)
	END

	IF(@Direccion='' OR @Direccion IS NULL)
	BEGIN
		RAISERROR ('La contrase�a no puede estar vacia',16,1)
	END

	IF(LEN(@Direccion)<250)
	BEGIN
		RAISERROR ('La longitud de la Direccion ingresada es mayor a la permitida',16,1)
	END

	IF(@Telefono='' OR @Telefono IS NULL)
	BEGIN
		RAISERROR ('El telefono no puede estar vacio',16,1)
	END

	IF(LEN(@Telefono) > 8 OR LEN(@Telefono) < 8)
	BEGIN
		RAISERROR ('La longitud de caracteres del telefono no es correcta',16,1)
	END
	
	--Operaciones
	INSERT INTO Proveedores (Nombre, Direccion, Telefono, Estado)
	VALUES (@Nombre, @Direccion, @Telefono, 1)

	--Resultados
	DECLARE @Id INT = SCOPE_IDENTITY ()
	SELECT * FROM Proveedores WHERE Id = @Id
	
END

CREATE PROCEDURE PROVEEDORES_READ
@Id int,
@Nombre nvarchar(max),
@Direccion nvarchar(max),
@Telefono char(8)
AS
BEGIN
	SELECT * FROM Proveedores
	WHERE (
	(@Id IS NULL OR Id=@Id)AND
	(@Nombre IS NULL OR Nombre LIKE '%'+@Nombre+'%' )AND
	(@Direccion  IS NULL OR Direccion LIKE '%'+@Direccion+'%' )AND
	(@Telefono  IS NULL OR Telefono = @Telefono )
	)
END

CREATE PROCEDURE PROVEEDORES_UPDATE
@Id int,
@Nombre nvarchar(max),
@Direccion nvarchar(max),
@Telefono char(8)
AS
BEGIN 
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN(@Nombre)>100)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el l�mite establecido',16,1)
	END

	IF(@Direccion='' OR @Direccion IS NULL)
	BEGIN
		RAISERROR ('La contrase�a no puede estar vacia',16,1)
	END

	IF(LEN(@Direccion)<250)
	BEGIN
		RAISERROR ('La longitud de la Direccion ingresada es mayor a la permitida',16,1)
	END

	IF(@Telefono='' OR @Telefono IS NULL)
	BEGIN
		RAISERROR ('El telefono no puede estar vacio',16,1)
	END

	IF(LEN(@Telefono) > 8 OR LEN(@Telefono) < 8)
	BEGIN
		RAISERROR ('La longitud de caracteres del telefono no es correcta',16,1)
	END

	--Operaciones
	UPDATE Proveedores SET Nombre=@Nombre, Direccion=@Direccion, Telefono=@Telefono
	WHERE Id=@Id

	--RESULTADO 
	SELECT * FROM Proveedores WHERE Id=@Id
END


CREATE PROCEDURE PROVEEDORES_DELETE
@Id int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del Proveedor no es v�lido', 16, 1)
	END

	--OPERACIONES 
	UPDATE Proveedores SET Estado =0 WHERE Id=@Id
	SELECT * FROM Proveedores WHERE Id=@Id
END

--CRUD Proveedores

--CRUD Usuarios

CREATE PROCEDURE USUARIOS_CREATE
@Nombre nvarchar(max),
@Contrase�a nvarchar(max),
@Rol nvarchar(max),
@IdEmpleado int
AS
BEGIN
	--Validaciones
	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN(@Nombre) > 100)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el limite establecido',16,1)
	END

	IF(@Contrase�a='' OR @Contrase�a IS NULL)
	BEGIN
		RAISERROR ('La contrase�a no puede estar vacia',16,1)
	END

	IF(LEN(@Contrase�a) < 5)
	BEGIN
		RAISERROR ('Contrase�a muy corta, ingrese una nueva contrase�a',16,1)
	END

	IF(@Rol='' OR @Rol IS NULL)
	BEGIN
		RAISERROR ('El rol no puede estar vacio',16,1)
	END

	IF(LEN(@Rol)>40)
	BEGIN
		RAISERROR ('La longitud de caracteres del rol supera el limite establecido',16,1)
	END

	IF(@IdEmpleado <= 0 OR @IdEmpleado IS NULL)
	BEGIN
		RAISERROR ('El ID del empleado no se encontro en los registros',16,1)
	END

	--Operaciones
	INSERT INTO Usuarios (Nombre, Contrase�a, Rol, Estado, IdEmpleado)
	VALUES (@Nombre, ENCRYPTBYPASSPHRASE(@Contrase�a, @Contrase�a), @Rol, 1, @IdEmpleado)

	--Resultados
	DECLARE @Id INT = SCOPE_IDENTITY()
	SELECT * FROM Usuarios WHERE Id = @Id
	
END

CREATE PROCEDURE USUARIOS_READ
@Id int,
@Nombre nvarchar(max),
@Contrase�a nvarchar(max),
@Rol nvarchar(40),
@IdEmpleado int
AS
BEGIN
	SELECT * FROM Usuarios
	WHERE (
	(@Id IS NULL OR Id=@Id)AND
	(@Nombre IS NULL OR Nombre LIKE '%'+@Nombre+'%' )AND
	(@Contrase�a  IS NULL OR Contrase�a LIKE '%'+ CONVERT(varchar(max), DECRYPTBYPASSPHRASE(@Contrase�a, Contrase�a)) +'%' )AND
	(@Rol  IS NULL OR Rol LIKE '%'+@Rol+'%' )AND
	(@IdEmpleado IS NULL OR IdEmpleado=@IdEmpleado)
	)
END

CREATE PROCEDURE USUARIOS_UPDATE
@Id int,
@Nombre nvarchar(max),
@Contrase�a nvarchar(max),
@Rol nvarchar(40),
@IdEmpleado int
AS
BEGIN 
	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del cliente no es v�lido', 16, 1)
	END

	IF(@Nombre='' OR @Nombre IS NULL)
	BEGIN
		RAISERROR ('El nombre no puede estar vacio',16,1)
	END

	IF(LEN(@Nombre) > 100)
	BEGIN
		RAISERROR ('La longitud de caracteres del nombre supera el limite establecido',16,1)
	END

	IF(@Contrase�a='' OR @Contrase�a IS NULL)
	BEGIN
		RAISERROR ('La contrase�a no puede estar vacia',16,1)
	END

	IF(LEN(@Contrase�a) < 5)
	BEGIN
		RAISERROR ('Contrase�a muy corta, ingrese una nueva contrase�a',16,1)
	END

	IF(@Rol='' OR @Rol IS NULL)
	BEGIN
		RAISERROR ('El rol no puede estar vacio',16,1)
	END

	IF(LEN(@Rol)>40)
	BEGIN
		RAISERROR ('La longitud de caracteres del rol supera el limite establecido',16,1)
	END

	IF(@IdEmpleado <= 0 OR @IdEmpleado IS NULL)
	BEGIN
		RAISERROR ('El ID del empleado no se encontro en los registros',16,1)
	END

	--Operaciones
	UPDATE Usuarios SET Nombre=@Nombre, Contrase�a = ENCRYPTBYPASSPHRASE(@Contrase�a, @Contrase�a), Rol=@Rol, IdEmpleado=@IdEmpleado 
	WHERE Id=@Id

	--RESULTADO 
	SELECT * FROM Usuarios WHERE Id=@Id
END

CREATE PROCEDURE USUARIOS_DELETE
@Id int
AS
BEGIN

	--Validaciones
	IF (@Id <= 0 OR @Id IS NULL)
	BEGIN
		RAISERROR('El ID del cliente no es v�lido', 16, 1)
	END

	--OPERACIONES 
	UPDATE Usuarios SET Estado =0 WHERE Id=@Id
	SELECT * FROM Clientes WHERE Id=@Id
END

CREATE PROCEDURE USUARIOS_LOGIN
@Nombre varchar(max),
@Contrase�a varchar(max)
AS
BEGIN
	--Operaciones
	IF NOT EXISTS (SELECT * FROM Usuarios WHERE Nombre = @Nombre AND CONVERT(nvarchar(max), DECRYPTBYPASSPHRASE(@Contrase�a, Contrase�a)) = @Contrase�a)
	BEGIN
		RAISERROR('El nombre de usuario o contrase�a no coinciden', 16, 1)
	END

	--Resultado
	SELECT
		*
	FROM
		Usuarios
	WHERE (
	(Nombre = @Nombre) AND
	(CONVERT(nvarchar(MAX), DECRYPTBYPASSPHRASE(@Contrase�a, Contrase�a)) = @Contrase�a) AND
	(Estado <> 0))
	
END

--CRUD Usuarios