BACKUP DATABASE ElMirador TO DISK = 'E:\ElMirador\ElMirador.bak'

RESTORE DATABASE Murray FROM DISK = 'E:\Murray\Murray.bak' WITH REPLACE